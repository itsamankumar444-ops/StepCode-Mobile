import http from "node:http";

const PORT = Number(process.env.PORT || 8787);
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const OPENAI_MODEL = process.env.OPENAI_MODEL;
const MAX_INPUT = 12000;

if (!OPENAI_API_KEY) {
  console.error("Missing OPENAI_API_KEY. Add it to the server environment; never put it in the APK.");
  process.exit(1);
}
if (!OPENAI_MODEL) {
  console.error("Missing OPENAI_MODEL. Set this to a model enabled for your API project.");
  process.exit(1);
}

function json(res, status, body) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(body));
}

async function readBody(req) {
  let body = "";
  for await (const chunk of req) {
    body += chunk;
    if (body.length > MAX_INPUT) throw new Error("request too large");
  }
  return JSON.parse(body || "{}");
}

function safeText(value, max = 1200) {
  return String(value ?? "").replace(/[\u0000-\u001F\u007F]/g, " ").slice(0, max);
}

const server = http.createServer(async (req, res) => {
  if (req.method === "GET" && req.url === "/health") return json(res, 200, { ok: true });
  if (req.method !== "POST" || req.url !== "/api/hints") return json(res, 404, { error: "not_found" });

  try {
    const body = await readBody(req);
    const course = safeText(body.course, 40);
    const levelTitle = safeText(body.levelTitle, 100);
    const question = safeText(body.question, 1600);
    const input = `Course: ${course}\nLevel: ${levelTitle}\nQuestion: ${question}`;

    const r = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${OPENAI_API_KEY}` },
      body: JSON.stringify({
        model: OPENAI_MODEL,
        instructions: "You are Blocky, a cheerful coding tutor for children. Give one short hint, not the answer. Use simple words, avoid jargon, never ask for personal information, and keep the hint under 45 words.",
        input,
        max_output_tokens: 120,
        store: false,
        safety_identifier: "stepcode-kid-tutor",
      }),
    });

    const data = await r.json();
    if (!r.ok) return json(res, 502, { error: "openai_error", detail: data?.error?.message || "OpenAI request failed" });
    const hint = typeof data.output_text === "string" ? data.output_text.trim() : "Think about what the question is asking you to do first.";
    return json(res, 200, { hint });
  } catch (error) {
    console.error(error);
    return json(res, 400, { error: "bad_request", detail: error instanceof Error ? error.message : "unknown error" });
  }
});

server.listen(PORT, () => console.log(`StepCode hint service listening on :${PORT}`));
