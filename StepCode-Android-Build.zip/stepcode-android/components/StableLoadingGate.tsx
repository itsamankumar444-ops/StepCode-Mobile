import React, { useEffect, useState } from "react";
import { ActivityIndicator, StyleSheet, Text, View } from "react-native";

export function StableLoadingGate({ ready, children }: { ready: boolean; children: React.ReactNode }) {
  const [settled, setSettled] = useState(false);
  useEffect(() => {
    const id = setTimeout(() => setSettled(true), ready ? 120 : 1600);
    return () => clearTimeout(id);
  }, [ready]);

  if (!settled) {
    return <View style={styles.root}><Text style={styles.logo}>StepCode</Text><ActivityIndicator size="large" /><Text style={styles.note}>Getting your coding world ready…</Text></View>;
  }
  return <>{children}</>;
}

const styles = StyleSheet.create({
  root: { flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#F7F9FF", paddingHorizontal: 28 },
  logo: { fontSize: 42, fontWeight: "900", color: "#23345D", marginBottom: 22 },
  note: { marginTop: 14, color: "#6B7898", fontSize: 14 },
});
