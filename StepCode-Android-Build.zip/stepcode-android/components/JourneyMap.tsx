import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";

export function JourneyMap({ levels, currentLevel, completed, onPress }: {
  levels: Array<{ id: string; title: string; difficulty: "easy" | "medium" | "advanced"; xp: number }>;
  currentLevel: number;
  completed: string[];
  onPress: (index: number) => void;
}) {
  return <View style={styles.root}>
    <Text style={styles.title}>Your coding journey</Text>
    <Text style={styles.subtitle}>Unlock each step, collect XP, and meet your course mascot.</Text>
    <View style={styles.path}>{levels.map((l, i) => {
      const done = completed.includes(l.id);
      const active = i === currentLevel;
      const locked = i > currentLevel;
      return <React.Fragment key={l.id}>
        {i > 0 && <View style={[styles.connector, done || active ? styles.connectorActive : undefined]} />}
        <Pressable disabled={locked} onPress={() => onPress(i)} style={[styles.node, done && styles.done, active && styles.active, locked && styles.locked]}>
          <Text style={styles.nodeIcon}>{done ? "✓" : locked ? "🔒" : String(i + 1)}</Text>
          <Text numberOfLines={2} style={styles.nodeTitle}>{l.title}</Text>
          <Text style={styles.xp}>{l.xp} XP · {l.difficulty}</Text>
        </Pressable>
      </React.Fragment>;
    })}</View>
  </View>;
}

const styles = StyleSheet.create({
  root: { padding: 18 }, title: { color: "#202D4D", fontSize: 24, fontWeight: "900" }, subtitle: { color: "#6B7897", marginTop: 5, lineHeight: 20 },
  path: { marginTop: 18, alignItems: "center" }, connector: { width: 5, height: 24, borderRadius: 3, backgroundColor: "#DDE4F2" }, connectorActive: { backgroundColor: "#7A6AFF" },
  node: { width: "82%", minHeight: 84, borderRadius: 20, padding: 14, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#DEE5F4", shadowColor: "#23345D", shadowOpacity: 0.08, shadowRadius: 7, elevation: 2 },
  done: { borderColor: "#6DD6B0", backgroundColor: "#F4FFFA" }, active: { borderWidth: 2, borderColor: "#2D7FF9" }, locked: { opacity: 0.45 }, nodeIcon: { fontSize: 21, fontWeight: "900", color: "#2D7FF9" }, nodeTitle: { marginTop: 5, color: "#283654", fontWeight: "900" }, xp: { marginTop: 3, color: "#7A88A2", fontSize: 11, textTransform: "uppercase", fontWeight: "800" },
});
