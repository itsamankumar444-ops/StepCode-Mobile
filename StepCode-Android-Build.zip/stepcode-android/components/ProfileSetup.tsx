import React, { useState } from "react";
import { Image, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import * as ImagePicker from "expo-image-picker";

const AVATARS = ["🧑‍💻", "🦊", "🐼", "🐸", "🦄", "🤖", "🐯", "🐨"];

export type StepCodeProfile = { username: string; avatarEmoji?: string; avatarUri?: string };

export function ProfileSetup({
  onComplete,
  onGoogle,
}: { onComplete: (profile: StepCodeProfile) => void; onGoogle?: () => void }) {
  const [username, setUsername] = useState("");
  const [avatarEmoji, setAvatarEmoji] = useState("🧑‍💻");
  const [avatarUri, setAvatarUri] = useState<string | undefined>();

  const pickPhoto = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) return;
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"], allowsEditing: true, aspect: [1, 1], quality: 0.8 });
    if (!result.canceled) setAvatarUri(result.assets[0]?.uri);
  };

  const ready = username.trim().length >= 2 && username.trim().length <= 20;
  return (
    <View style={styles.root}>
      <Text style={styles.kicker}>WELCOME, CODER!</Text>
      <Text style={styles.title}>Choose your coding name</Text>
      <Text style={styles.subtitle}>You can use a nickname. A profile picture is optional.</Text>

      <Pressable onPress={pickPhoto} style={styles.avatarRing}>
        {avatarUri ? <Image source={{ uri: avatarUri }} style={styles.avatarImage} /> : <Text style={styles.avatarText}>{avatarEmoji}</Text>}
        <View style={styles.plus}><Text style={styles.plusText}>+</Text></View>
      </Pressable>

      <Text style={styles.label}>USERNAME</Text>
      <TextInput value={username} onChangeText={setUsername} maxLength={20} autoCapitalize="none" placeholder="e.g. CodeTiger" style={styles.input} />

      <Text style={styles.label}>PICK A CHARACTER</Text>
      <View style={styles.avatarGrid}>{AVATARS.map((a) => <Pressable key={a} onPress={() => { setAvatarEmoji(a); setAvatarUri(undefined); }} style={[styles.choice, avatarEmoji === a && !avatarUri ? styles.choiceSelected : undefined]}><Text style={styles.choiceText}>{a}</Text></Pressable>)}</View>

      {onGoogle && <Pressable style={styles.google} onPress={onGoogle}><Text style={styles.googleG}>G</Text><Text style={styles.googleText}>Continue with Google</Text></Pressable>}
      <Pressable disabled={!ready} onPress={() => onComplete({ username: username.trim(), avatarEmoji, avatarUri })} style={[styles.continue, !ready && styles.continueDisabled]}><Text style={styles.continueText}>Start my journey</Text></Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#F7F9FF", paddingHorizontal: 20, paddingTop: 32 },
  kicker: { fontSize: 12, fontWeight: "900", letterSpacing: 1.2, color: "#7A6AFF" },
  title: { marginTop: 8, color: "#202D4D", fontSize: 30, fontWeight: "900" },
  subtitle: { marginTop: 7, color: "#687692", lineHeight: 21 },
  avatarRing: { alignSelf: "center", marginVertical: 20, width: 108, height: 108, borderRadius: 54, backgroundColor: "#E7F0FF", borderWidth: 5, borderColor: "#FFFFFF", alignItems: "center", justifyContent: "center", shadowColor: "#23345D", shadowOpacity: 0.12, shadowRadius: 12, elevation: 6 },
  avatarImage: { width: 96, height: 96, borderRadius: 48 }, avatarText: { fontSize: 53 },
  plus: { position: "absolute", right: -2, bottom: 2, width: 30, height: 30, borderRadius: 15, alignItems: "center", justifyContent: "center", backgroundColor: "#2D7FF9", borderWidth: 3, borderColor: "#FFFFFF" }, plusText: { color: "#FFFFFF", fontSize: 21, fontWeight: "900", marginTop: -1 },
  label: { marginTop: 12, color: "#6B7897", fontSize: 11, fontWeight: "900", letterSpacing: 0.8 },
  input: { marginTop: 7, backgroundColor: "#FFFFFF", borderRadius: 14, borderWidth: 1, borderColor: "#DCE3F2", paddingHorizontal: 14, paddingVertical: 13, fontSize: 16, color: "#202D4D" },
  avatarGrid: { flexDirection: "row", flexWrap: "wrap", gap: 9, marginTop: 8 },
  choice: { width: 42, height: 42, borderRadius: 13, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#DEE5F4" },
  choiceSelected: { borderWidth: 2, borderColor: "#7A6AFF", backgroundColor: "#F0EEFF" }, choiceText: { fontSize: 24 },
  google: { marginTop: 18, minHeight: 48, borderRadius: 14, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#D8DFEC", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 9 },
  googleG: { fontWeight: "900", fontSize: 19, color: "#4285F4" }, googleText: { color: "#34415E", fontWeight: "800" },
  continue: { marginTop: 12, minHeight: 52, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: "#2D7FF9" }, continueDisabled: { opacity: 0.45 }, continueText: { color: "#FFFFFF", fontWeight: "900", fontSize: 16 },
});
