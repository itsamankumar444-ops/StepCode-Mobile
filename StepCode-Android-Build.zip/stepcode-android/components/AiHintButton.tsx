import React, { useState } from "react";
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from "react-native";

export function AiHintButton({ apiBaseUrl, course, levelTitle, question, fallbackHint }: {
  apiBaseUrl: string;
  course: string;
  levelTitle: string;
  question: string;
  fallbackHint: string;
}) {
  const [hint, setHint] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const getHint = async () => {
    setLoading(true);
    try {
      const r = await fetch(`${apiBaseUrl.replace(/\/$/, "")}/api/hints`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ course, levelTitle, question }) });
      const data = await r.json();
      setHint(typeof data.hint === "string" && data.hint.trim() ? data.hint.trim() : fallbackHint);
    } catch { setHint(fallbackHint); }
    finally { setLoading(false); }
  };
  return <View>
    <Pressable style={styles.button} onPress={getHint} disabled={loading}><Text style={styles.icon}>💡</Text><Text style={styles.buttonText}>{loading ? "Thinking…" : "Ask Blocky for a hint"}</Text>{loading && <ActivityIndicator size="small" />}</Pressable>
    {hint && <View style={styles.card}><Text style={styles.cardTitle}>Blocky’s clue</Text><Text style={styles.cardText}>{hint}</Text></View>}
  </View>;
}

const styles = StyleSheet.create({
  button: { minHeight: 46, paddingHorizontal: 15, borderRadius: 14, backgroundColor: "#FFF3C7", flexDirection: "row", alignItems: "center", gap: 9 },
  icon: { fontSize: 19 }, buttonText: { color: "#664E00", fontWeight: "800", flex: 1 },
  card: { marginTop: 9, padding: 14, borderRadius: 16, backgroundColor: "#FFFDF5", borderWidth: 1, borderColor: "#F4DE92" },
  cardTitle: { fontWeight: "800", color: "#705700", marginBottom: 3 }, cardText: { color: "#62572F", lineHeight: 20 },
});
