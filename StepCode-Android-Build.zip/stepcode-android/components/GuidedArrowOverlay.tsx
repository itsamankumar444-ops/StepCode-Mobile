import React from "react";
import { View, Text, Pressable, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";

export function GuidedArrowOverlay({
  title,
  message,
  visible,
  onNext,
  onSkip,
}: {
  title: string;
  message: string;
  visible: boolean;
  onNext: () => void;
  onSkip?: () => void;
}) {
  if (!visible) return null;
  return (
    <View pointerEvents="box-none" style={StyleSheet.absoluteFill}>
      <View style={styles.card}>
        <View style={styles.badge}><Ionicons name="sparkles" size={16} color="#ffffff" /><Text style={styles.badgeText}>TIP</Text></View>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.message}>{message}</Text>
        <View style={styles.row}>
          {onSkip ? <Pressable onPress={onSkip}><Text style={styles.skip}>Skip</Text></Pressable> : <View />}
          <Pressable onPress={onNext} style={styles.next}><Text style={styles.nextText}>Got it</Text><Ionicons name="arrow-forward" size={17} color="#ffffff" /></Pressable>
        </View>
      </View>
      <View style={styles.arrow}><Ionicons name="arrow-down" size={42} color="#ffb703" /></View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { position: "absolute", left: 18, right: 18, bottom: 28, backgroundColor: "#ffffff", borderRadius: 22, padding: 18, shadowColor: "#000", shadowOpacity: 0.14, shadowRadius: 16, shadowOffset: { width: 0, height: 8 }, elevation: 8 },
  badge: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#7c5cff", borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5 },
  badgeText: { color: "#fff", fontWeight: "800", fontSize: 11 },
  title: { marginTop: 10, fontSize: 20, fontWeight: "800", color: "#232f4d" },
  message: { marginTop: 6, color: "#5f6f91", lineHeight: 21, fontSize: 14 },
  row: { marginTop: 15, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  skip: { color: "#8190ae", fontWeight: "700", padding: 8 },
  next: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "#2d7ff9", borderRadius: 14, paddingHorizontal: 15, paddingVertical: 11 },
  nextText: { color: "#fff", fontWeight: "800" },
  arrow: { position: "absolute", right: 42, bottom: 176 },
});
