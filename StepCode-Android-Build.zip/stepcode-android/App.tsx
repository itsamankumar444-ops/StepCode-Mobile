import React, {useMemo, useState} from 'react';
import {SafeAreaView, ScrollView, StyleSheet, Text, Pressable, View, Image} from 'react-native';
import {ProfileSetup, StepCodeProfile} from './components/ProfileSetup';
import {JourneyMap} from './components/JourneyMap';
import {curriculum} from './src/curriculum';

const mascots:any = {
  python: {name:'Mr. Snakey', emoji:'🐍', blurb:'Your friendly Python guide'},
  cpp: {name:'Dr. Cilly', emoji:'🤖', blurb:'Your C++ science coach'},
  blocks: {name:'Blocky', emoji:'🧩', blurb:'Your block-building buddy'},
};

export default function App(){
  const [profile,setProfile]=useState<StepCodeProfile|null>(null);
  const [course,setCourse]=useState<'python'|'cpp'|'blocks'>('blocks');
  const [started,setStarted]=useState(false);
  const [current,setCurrent]=useState(0);
  const [completed,setCompleted]=useState<string[]>([]);
  const levels = useMemo(()=>{
    const c:any = (curriculum as any).filter((x:any)=>x.course===course);
    return c;
  },[course]);
  if(!profile) return <SafeAreaView style={styles.safe}><ProfileSetup onComplete={setProfile} onGoogle={()=>{}} /></SafeAreaView>;
  const m=mascots[course];
  const level=levels[current] || levels[0];
  return <SafeAreaView style={styles.safe}>
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.header}><View><Text style={styles.brand}>StepCode</Text><Text style={styles.greeting}>Hey {profile.username}! 👋</Text></View><Text style={styles.avatar}>{profile.avatarEmoji||'🧑‍💻'}</Text></View>
      <View style={styles.hero}><Image source={require('./assets/stepcode-mascots.png')} style={styles.mascots}/><View style={styles.heroText}><Text style={styles.heroTitle}>Small steps. Big creators.</Text><Text style={styles.heroSub}>Learn coding through a fun journey.</Text></View></View>
      {!started ? <>
        <Text style={styles.section}>Choose your course</Text>
        <View style={styles.courseRow}>{(['blocks','python','cpp'] as const).map(k=><Pressable key={k} onPress={()=>setCourse(k)} style={[styles.course,course===k&&styles.courseActive]}><Text style={styles.courseEmoji}>{mascots[k].emoji}</Text><Text style={styles.courseName}>{k==='blocks'?'Block Coding':k==='python'?'Python':'C++'}</Text><Text style={styles.courseSub}>{mascots[k].name}</Text></Pressable>)}</View>
        <Pressable style={styles.start} onPress={()=>setStarted(true)}><Text style={styles.startText}>Start Journey 🚀</Text></Pressable>
      </> : <>
        <View style={styles.mascotCard}><Text style={styles.bigEmoji}>{m.emoji}</Text><View style={{flex:1}}><Text style={styles.cardTitle}>{m.name}</Text><Text style={styles.cardSub}>{m.blurb}</Text></View></View>
        <JourneyMap levels={levels} currentLevel={current} completed={completed} onPress={setCurrent}/>
        <View style={styles.lesson}><Text style={styles.kicker}>{level?.difficulty?.toUpperCase()||'LEVEL'} • {level?.xp||10} XP</Text><Text style={styles.lessonTitle}>{level?.title||'Your next coding challenge'}</Text><Text style={styles.question}>{level?.question||'Stack blocks, test your idea, and see what happens!'}</Text><Pressable style={styles.test} onPress={()=>{if(level?.id&&!completed.includes(level.id))setCompleted([...completed,level.id]); if(current<levels.length-1)setCurrent(current+1)}}><Text style={styles.testText}>Run Demo ▶</Text></Pressable></View>
      </>}
    </ScrollView>
  </SafeAreaView>
}
const styles=StyleSheet.create({safe:{flex:1,backgroundColor:'#F7F9FD'},container:{padding:18,paddingBottom:40},header:{flexDirection:'row',justifyContent:'space-between',alignItems:'center'},brand:{fontSize:30,fontWeight:'900',color:'#24345D'},greeting:{color:'#71809D',marginTop:2},avatar:{fontSize:34},hero:{marginTop:18,borderRadius:26,backgroundColor:'#FFF',overflow:'hidden',borderWidth:1,borderColor:'#E4E9F3'},mascots:{width:'100%',height:180,resizeMode:'cover'},heroText:{padding:16},heroTitle:{fontSize:22,fontWeight:'900',color:'#25355E'},heroSub:{marginTop:4,color:'#74819B'},section:{marginTop:24,fontSize:21,fontWeight:'900',color:'#25355E'},courseRow:{flexDirection:'row',gap:9,marginTop:12},course:{flex:1,backgroundColor:'#FFF',borderRadius:18,padding:12,borderWidth:1,borderColor:'#E0E6F2',minHeight:125},courseActive:{borderWidth:2,borderColor:'#7B68EE'},courseEmoji:{fontSize:32},courseName:{fontWeight:'900',color:'#2A385B',marginTop:5},courseSub:{fontSize:11,color:'#7886A2',marginTop:3},start:{marginTop:20,borderRadius:18,backgroundColor:'#2D7FF9',padding:17,alignItems:'center'},startText:{color:'#FFF',fontSize:18,fontWeight:'900'},mascotCard:{marginTop:20,flexDirection:'row',alignItems:'center',gap:15,backgroundColor:'#FFF',padding:15,borderRadius:20},bigEmoji:{fontSize:48},cardTitle:{fontSize:21,fontWeight:'900',color:'#27375C'},cardSub:{color:'#75829D',marginTop:2},lesson:{marginTop:18,backgroundColor:'#FFF',padding:18,borderRadius:22,borderWidth:1,borderColor:'#E0E6F2'},kicker:{fontSize:11,fontWeight:'900',color:'#7B68EE'},lessonTitle:{fontSize:22,fontWeight:'900',color:'#26365B',marginTop:5},question:{fontSize:15,lineHeight:22,color:'#566581',marginTop:9},test:{marginTop:15,padding:15,borderRadius:15,backgroundColor:'#27B98A',alignItems:'center'},testText:{color:'#FFF',fontWeight:'900',fontSize:16}});
