# Feature wiring checklist

## Onboarding

1. Welcome screen presents two choices: Google or username.
2. Username route creates a local anonymous profile.
3. Optional profile photo is stored locally; do not require camera/gallery permission unless the user taps the photo picker.
4. After profile setup, route to the course map.

## Scratch sandbox

The new engine treats operator/Boolean blocks as values that can plug into other blocks. The UI should therefore have two drop targets:

- stack socket: command block snapped below another command block
- input socket: reporter/Boolean block snapped inside a rounded field of a command/control block

A C-shaped block owns a nested child list. `repeat`, `if`, and `ifElse` are not just ordered cards; they are actual containers.

Recommended interactions:
- drag from palette → snap to a compatible socket
- drag a nested block out → it returns to the palette/work area
- tap Run → animate the mascot while executing the interpreter steps
- tap Stop → cancel the current animation and keep the program intact
- tap Undo → restore the previous stack state

## Level interaction mix

Use one lesson screen but vary the activity card:

- MCQ: 2–4 large tappable choices, instant feedback, mascot reaction.
- Fill blank: single input, letter chips on mobile, hint after one wrong try.
- Match: two columns of cards, tap left/right to pair, gentle snap animation.
- Build: Scratch sandbox with a target result and a Run button.

## Loading/start fix

Do not derive button visibility directly from splash-screen animation state. Keep `ready` and `showStart` as separate state, wait for navigation/fonts/data to settle, then render the Start button. `StableLoadingGate.tsx` demonstrates the structure.

## Guided arrows

Store guide steps per level, for example:

```ts
const guide = [
  { title: "Start here", message: "Drag the yellow flag into the workspace." },
  { title: "Add an action", message: "Place Move below the flag so the mascot knows what to do." },
  { title: "Try a loop", message: "Drop Repeat around Move to make one action happen several times." },
];
```

Advance the guide after the expected UI event rather than after a timer.
