# StepCode OpenAI hints

The mobile client must **not** contain the OpenAI secret key. OpenAI explicitly advises that API keys should never be deployed in client-side apps; keep the key on a server and send only your own short-lived API requests from the app. citeturn633338search5turn633338search8

## Create a key

Create a secret key from the API platform's API key page. The full secret is shown only when created; if it is lost, rotate/create a new key. citeturn633338search0turn633338search6

## Run the local hint server

```bash
cd server
cp .env.example .env
# Put your real key/model into the environment (do not commit .env)
export OPENAI_API_KEY='sk-proj-...'
export OPENAI_MODEL='your-enabled-model'
npm start
```

The service uses the OpenAI Responses API endpoint (`POST /v1/responses`) to return a short child-friendly hint. citeturn633338search4

## Production

Deploy `server/openai-hints.mjs` behind HTTPS (Cloud Run, Render, Railway, Fly.io, or your own server), add rate limiting, and set a conservative per-user request limit. The app should call:

```text
POST https://YOUR-DOMAIN/api/hints
```

The server should remain the only component that knows `OPENAI_API_KEY`.
