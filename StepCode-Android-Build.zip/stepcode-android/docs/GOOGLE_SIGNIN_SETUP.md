# StepCode Google sign-in setup

The existing APK is an Expo SDK 54 / React Native release and already contains an OAuth callback route and a backend exchange flow. The cleanest repair is to keep that architecture and configure a real Google OAuth client for the production Android package.

## 1. Create the Google OAuth credentials

In Google Cloud Console, create/select a project, configure the OAuth consent screen, then create Android and Web OAuth 2.0 client IDs.

For Android, use:
- Package name: `com.app.stepcode`
- SHA-1: use the certificate for the build variant that users install. For a production Play build, add the Play App Signing certificate as documented by Expo.

Expo's current Google-auth guide says native Google sign-in requires a development build/custom native code rather than Expo Go, and recommends `@react-native-google-signin/google-signin` or `react-native-nitro-google-signin`. citehttps://docs.expo.dev/guides/google-authentication/

## 2. App-side configuration

Set these environment variables for the editable source project:

```text
EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID=your-web-client-id.apps.googleusercontent.com
EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID=your-android-client-id.apps.googleusercontent.com
```

Use the Web Client ID in the library configuration where required by the provider, while the Android Client ID must match the package name and SHA-1 certificate.

## 3. Use the ID token on the server

The mobile app should obtain a Google ID token and send it to your backend. The backend should validate that token and then create/attach the StepCode account. Keep the Google OAuth exchange server-side where possible.

## 4. Why the current APK likely fails

The shipped bundle contains `com.app.stepcode`, an OAuth callback route, and strings indicating an OAuth/mobile exchange and a backend session token. That strongly suggests the UI is wired to an OAuth backend, but the release APK does not prove that the Google Console client IDs/certificate fingerprints are configured correctly.

## 5. Profile flow

After the Welcome screen, use this order:

`Welcome → Continue with Google OR Choose a username → optional profile picture → choose mascot/course → Home`

Do not require a child to provide an email when using the local username route. Store the local profile with a generated anonymous user ID and keep the profile picture optional.
