# StepCode Android build project

This is a buildable Expo/React Native Android scaffold containing the StepCode upgrade features prepared from the supplied files.

## Build an installable APK

1. Install Node.js 20+.
2. `npm install`
3. `npx eas login`
4. `npx eas build -p android --profile preview`

The `preview` profile is configured to output an `.apk` for direct Android installation.

This project is a clean integration scaffold, not a byte-for-byte reconstruction of the original compiled APK. To merge every existing StepCode screen, provide the original editable StepCode source project.

## OpenAI

Do not put the OpenAI key in the mobile app. Run `server/openai-hints.mjs` on a backend and set `OPENAI_API_KEY` there.
