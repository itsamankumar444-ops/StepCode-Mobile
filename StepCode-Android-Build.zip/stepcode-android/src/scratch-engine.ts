// StepCode Scratch-style block engine v2.
// Keeps the original stack/block API compatible while adding real Scratch-like
// expression sockets, variables, conditionals, and nested control blocks.

export type BlockCategory = "events" | "motion" | "looks" | "sound" | "control" | "operators" | "variables";
export type FieldType = "number" | "text" | "variable" | "choice";
export type BlockShape = "hat" | "stack" | "c" | "reporter" | "boolean";

export type FieldSpec = {
  key: string;
  type: FieldType;
  default: string;
  min?: number;
  max?: number;
  step?: number;
  maxLength?: number;
  options?: string[];
};

export type InputValue = string | StackBlock;

export type BlockDef = {
  type: string;
  category: BlockCategory;
  shape: BlockShape;
  label: string;
  fields: FieldSpec[];
  inputs?: string[];
  isHat?: boolean;
  isContainer?: boolean;
  childrenCount?: 1 | 2;
};

export type StackBlock = {
  uid: string;
  type: string;
  values: Record<string, string>;
  inputs?: Record<string, InputValue>;
  children?: StackBlock[];
  elseChildren?: StackBlock[];
};

export type ExecutionState = {
  x: number;
  rotation: number;
  scale: number;
  variables: Record<string, number | string>;
  output: string[];
};

export const CATEGORY_META: Record<BlockCategory, { label: string; color: string; softColor: string; icon: string }> = {
  events: { label: "Events", color: "#FFC857", softColor: "#FFF6E0", icon: "flag" },
  motion: { label: "Motion", color: "#3BA7FF", softColor: "#E5F4FF", icon: "directions-run" },
  looks: { label: "Looks", color: "#9B6BFF", softColor: "#F1ECFF", icon: "chat-bubble" },
  sound: { label: "Sound", color: "#E94F8A", softColor: "#FFEBF3", icon: "volume-up" },
  control: { label: "Control", color: "#FF7A59", softColor: "#FFF0EA", icon: "repeat" },
  operators: { label: "Operators", color: "#27C7A5", softColor: "#E5FBF6", icon: "calculate" },
  variables: { label: "Variables", color: "#FF9F43", softColor: "#FFF1DF", icon: "data-object" },
};

export const CATEGORY_ORDER: BlockCategory[] = ["events", "motion", "looks", "sound", "control", "operators", "variables"];

export const BLOCK_DEFS: BlockDef[] = [
  { type: "flag", category: "events", shape: "hat", label: "When 🚩 tapped", fields: [], isHat: true },

  { type: "move", category: "motion", shape: "stack", label: "Move {n} steps", fields: [{ key: "n", type: "number", default: "10", min: 1, max: 100, step: 5 }] },
  { type: "turnRight", category: "motion", shape: "stack", label: "Turn right {n}°", fields: [{ key: "n", type: "number", default: "15", min: 5, max: 180, step: 5 }] },
  { type: "turnLeft", category: "motion", shape: "stack", label: "Turn left {n}°", fields: [{ key: "n", type: "number", default: "15", min: 5, max: 180, step: 5 }] },
  { type: "goHome", category: "motion", shape: "stack", label: "Go back to start", fields: [] },

  { type: "say", category: "looks", shape: "stack", label: "Say {text}", fields: [{ key: "text", type: "text", default: "Hello!", maxLength: 60 }] },
  { type: "think", category: "looks", shape: "stack", label: "Think {text}", fields: [{ key: "text", type: "text", default: "Hmm…", maxLength: 60 }] },
  { type: "grow", category: "looks", shape: "stack", label: "Grow by {n}%", fields: [{ key: "n", type: "number", default: "20", min: 5, max: 100, step: 5 }] },
  { type: "shrink", category: "looks", shape: "stack", label: "Shrink by {n}%", fields: [{ key: "n", type: "number", default: "20", min: 5, max: 80, step: 5 }] },

  { type: "playPop", category: "sound", shape: "stack", label: "Play pop sound", fields: [] },
  { type: "playChime", category: "sound", shape: "stack", label: "Play success chime", fields: [] },
  { type: "playSpark", category: "sound", shape: "stack", label: "Play spark sound", fields: [] },

  { type: "repeat", category: "control", shape: "c", label: "Repeat {n} times", fields: [{ key: "n", type: "number", default: "3", min: 1, max: 20, step: 1 }], isContainer: true, childrenCount: 1 },
  { type: "if", category: "control", shape: "c", label: "If {condition}", fields: [], inputs: ["condition"], isContainer: true, childrenCount: 1 },
  { type: "ifElse", category: "control", shape: "c", label: "If {condition} then / else", fields: [], inputs: ["condition"], isContainer: true, childrenCount: 2 },
  { type: "wait", category: "control", shape: "stack", label: "Wait {n} seconds", fields: [{ key: "n", type: "number", default: "1", min: 1, max: 5, step: 1 }] },

  { type: "addOp", category: "operators", shape: "reporter", label: "{a} + {b}", fields: [{ key: "a", type: "number", default: "5" }, { key: "b", type: "number", default: "3" }], inputs: ["a", "b"] },
  { type: "subOp", category: "operators", shape: "reporter", label: "{a} − {b}", fields: [{ key: "a", type: "number", default: "9" }, { key: "b", type: "number", default: "4" }], inputs: ["a", "b"] },
  { type: "mulOp", category: "operators", shape: "reporter", label: "{a} × {b}", fields: [{ key: "a", type: "number", default: "3" }, { key: "b", type: "number", default: "3" }], inputs: ["a", "b"] },
  { type: "divOp", category: "operators", shape: "reporter", label: "{a} ÷ {b}", fields: [{ key: "a", type: "number", default: "12" }, { key: "b", type: "number", default: "3" }], inputs: ["a", "b"] },
  { type: "compareGt", category: "operators", shape: "boolean", label: "{a} > {b}", fields: [{ key: "a", type: "number", default: "7" }, { key: "b", type: "number", default: "4" }], inputs: ["a", "b"] },
  { type: "compareLt", category: "operators", shape: "boolean", label: "{a} < {b}", fields: [{ key: "a", type: "number", default: "4" }, { key: "b", type: "number", default: "7" }], inputs: ["a", "b"] },
  { type: "compareEq", category: "operators", shape: "boolean", label: "{a} = {b}", fields: [{ key: "a", type: "number", default: "5" }, { key: "b", type: "number", default: "5" }], inputs: ["a", "b"] },
  { type: "andOp", category: "operators", shape: "boolean", label: "{a} and {b}", fields: [], inputs: ["a", "b"] },
  { type: "orOp", category: "operators", shape: "boolean", label: "{a} or {b}", fields: [], inputs: ["a", "b"] },
  { type: "notOp", category: "operators", shape: "boolean", label: "not {a}", fields: [], inputs: ["a"] },

  { type: "setVariable", category: "variables", shape: "stack", label: "Set {name} to {value}", fields: [{ key: "name", type: "variable", default: "score" }, { key: "value", type: "number", default: "0" }], inputs: ["value"] },
  { type: "changeVariable", category: "variables", shape: "stack", label: "Change {name} by {amount}", fields: [{ key: "name", type: "variable", default: "score" }, { key: "amount", type: "number", default: "1" }], inputs: ["amount"] },
  { type: "variableReporter", category: "variables", shape: "reporter", label: "{name}", fields: [{ key: "name", type: "variable", default: "score" }] },
];

export type RunStep = {
  log: string;
  dx?: number;
  rotateDelta?: number;
  scale?: number;
  say?: string;
  waitMs?: number;
  sound?: "pop" | "chime" | "spark";
  resetX?: boolean;
};

let uidCounter = 0;
function nextUid(type: string) {
  uidCounter += 1;
  return `${type}-${Date.now().toString(36)}-${uidCounter}`;
}

export function blockDef(type: string): BlockDef {
  const def = BLOCK_DEFS.find((b) => b.type === type);
  if (!def) throw new Error(`Unknown block type: ${type}`);
  return def;
}

export function blocksForCategory(category: BlockCategory): BlockDef[] {
  return BLOCK_DEFS.filter((b) => b.category === category && !b.isHat);
}

export function renderLabel(type: string, values: Record<string, string>): string {
  const def = blockDef(type);
  let label = def.label;
  for (const field of def.fields) label = label.replace(`{${field.key}}`, values[field.key] ?? field.default);
  return label;
}

export function createBlock(type: string): StackBlock {
  const def = blockDef(type);
  const values: Record<string, string> = {};
  for (const field of def.fields) values[field.key] = field.default;
  const block: StackBlock = { uid: nextUid(type), type, values };
  if (def.isContainer) block.children = [];
  if (def.childrenCount === 2) block.elseChildren = [];
  return block;
}

export function createHatBlock(): StackBlock { return createBlock("flag"); }

const MAX_STEPS = 160;

function numericLiteral(block: StackBlock, key: string, fallback = 0): number {
  const raw = Number(block.values[key]);
  return Number.isFinite(raw) ? raw : fallback;
}

export function interpretStack(stack: StackBlock[], edgeThreshold = 120): RunStep[] {
  const steps: RunStep[] = [];
  const state: ExecutionState = { x: 0, rotation: 0, scale: 1, variables: {}, output: [] };
  let truncated = false;

  const push = (step: RunStep) => {
    if (steps.length >= MAX_STEPS) { truncated = true; return; }
    steps.push(step);
  };

  const evalValue = (input: InputValue | undefined, fallback: number | string = 0): number | string => {
    if (typeof input === "undefined") return fallback;
    if (typeof input === "string") {
      if (Object.prototype.hasOwnProperty.call(state.variables, input)) return state.variables[input];
      const n = Number(input);
      return Number.isFinite(n) ? n : input;
    }
    return evalBlock(input);
  };

  const asNumber = (value: number | string, fallback = 0) => {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
  };

  const evalBlock = (block: StackBlock): number | string => {
    const input = (key: string) => evalValue(block.inputs?.[key], block.values[key] ?? 0);
    switch (block.type) {
      case "addOp": return asNumber(input("a")) + asNumber(input("b"));
      case "subOp": return asNumber(input("a")) - asNumber(input("b"));
      case "mulOp": return asNumber(input("a")) * asNumber(input("b"));
      case "divOp": return asNumber(input("a")) / Math.max(0.0001, asNumber(input("b"), 1));
      case "compareGt": return asNumber(input("a")) > asNumber(input("b"));
      case "compareLt": return asNumber(input("a")) < asNumber(input("b"));
      case "compareEq": return asNumber(input("a")) === asNumber(input("b"));
      case "andOp": return Boolean(evalValue(block.inputs?.a, false)) && Boolean(evalValue(block.inputs?.b, false));
      case "orOp": return Boolean(evalValue(block.inputs?.a, false)) || Boolean(evalValue(block.inputs?.b, false));
      case "notOp": return !Boolean(evalValue(block.inputs?.a, false));
      case "variableReporter": return state.variables[block.values.name] ?? 0;
      default: return block.values.value ?? 0;
    }
  };

  const run = (blocks: StackBlock[]) => {
    for (const block of blocks) {
      if (truncated) return;
      switch (block.type) {
        case "flag": push({ log: "🚩 Started!" }); break;
        case "move": {
          const n = Math.max(1, Math.min(100, asNumber(block.inputs?.n ?? block.values.n, 10)));
          state.x = Math.max(-140, Math.min(140, state.x + n));
          push({ log: `Moved ${n} steps`, dx: n });
          break;
        }
        case "turnRight": { const d = numericLiteral(block, "n", 15); state.rotation += d; push({ log: `Turned right ${d}°`, rotateDelta: d }); break; }
        case "turnLeft": { const d = numericLiteral(block, "n", 15); state.rotation -= d; push({ log: `Turned left ${d}°`, rotateDelta: -d }); break; }
        case "goHome": state.x = 0; push({ log: "Went back to start", resetX: true }); break;
        case "say": { const text = String(evalValue(block.inputs?.text, block.values.text || "Hello!")); push({ log: `Said “${text}”`, say: text }); break; }
        case "think": { const text = String(evalValue(block.inputs?.text, block.values.text || "Hmm…")); push({ log: `Thought “${text}”`, say: `💭 ${text}` }); break; }
        case "grow": { const p = numericLiteral(block, "n", 20); state.scale *= 1 + p / 100; push({ log: `Grew by ${p}%`, scale: 1 + p / 100 }); break; }
        case "shrink": { const p = numericLiteral(block, "n", 20); state.scale *= Math.max(0.4, 1 - p / 100); push({ log: `Shrank by ${p}%`, scale: Math.max(0.4, 1 - p / 100) }); break; }
        case "playPop": push({ log: "🔊 Pop!", sound: "pop" }); break;
        case "playChime": push({ log: "🔊 Success chime!", sound: "chime" }); break;
        case "playSpark": push({ log: "🔊 Spark!", sound: "spark" }); break;
        case "wait": { const s = Math.max(1, Math.min(5, numericLiteral(block, "n", 1))); push({ log: `Waited ${s}s`, waitMs: s * 700 }); break; }
        case "repeat": {
          const times = Math.max(1, Math.min(20, numericLiteral(block, "n", 3)));
          for (let i = 0; i < times; i++) { push({ log: `— repeat ${i + 1}/${times} —` }); run(block.children ?? []); }
          break;
        }
        case "if": if (Boolean(evalValue(block.inputs?.condition, false))) run(block.children ?? []); else push({ log: "Condition was false, so this branch was skipped." }); break;
        case "ifElse": if (Boolean(evalValue(block.inputs?.condition, false))) run(block.children ?? []); else run(block.elseChildren ?? []); break;
        case "setVariable": { const name = block.values.name || "score"; state.variables[name] = evalValue(block.inputs?.value, block.values.value ?? 0); push({ log: `Set ${name} to ${state.variables[name]}` }); break; }
        case "changeVariable": { const name = block.values.name || "score"; const current = asNumber(state.variables[name] ?? 0); const amount = asNumber(evalValue(block.inputs?.amount, block.values.amount ?? 1), 1); state.variables[name] = current + amount; push({ log: `Changed ${name} to ${state.variables[name]}` }); break; }
        default: if (blockDef(block.type).shape === "reporter" || blockDef(block.type).shape === "boolean") push({ log: `Computed ${String(evalBlock(block))}` }); break;
      }
    }
  };

  run(stack);
  if (truncated) steps.push({ log: "…the project hit the safe demo-step limit. Try simplifying the loop." });
  return steps;
}

export function stackToSummary(stack: StackBlock[]): string {
  const parts: string[] = [];
  const walk = (blocks: StackBlock[], depth: number) => {
    for (const block of blocks) {
      const indent = "  ".repeat(depth);
      parts.push(`${indent}${renderLabel(block.type, block.values)}`);
      if (block.children?.length) walk(block.children, depth + 1);
      if (block.elseChildren?.length) { parts.push(`${indent}else`); walk(block.elseChildren, depth + 1); }
    }
  };
  walk(stack, 0);
  return parts.join("\n");
}
