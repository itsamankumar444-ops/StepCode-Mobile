export type CourseId = "python" | "cpp" | "blocks";
export type Difficulty = "easy" | "medium" | "advanced";
export type QuestionType = "mcq" | "fill_blank" | "match" | "build";

export type Question =
  | { type: "mcq"; prompt: string; choices: string[]; answer: number; explanation: string }
  | { type: "fill_blank"; prompt: string; answer: string; explanation: string }
  | { type: "match"; prompt: string; pairs: Array<{ left: string; right: string }>; explanation: string }
  | { type: "build"; prompt: string; goal: string; acceptedPatterns: string[]; explanation: string };

export type Level = {
  id: string;
  course: CourseId;
  difficulty: Difficulty;
  title: string;
  mascot: "Mr. Snakey" | "Dr. Cilly" | "Blocky";
  xp: number;
  questions: Question[];
  hint: string;
};

const difficultyXp: Record<Difficulty, number> = { easy: 10, medium: 20, advanced: 35 };

const pythonBanks = {
  easy: [
    ["What symbol starts a Python comment?", ["//", "#", "<!--", "**"], 1, "Python comments start with #."],
    ["Which function displays text?", ["show()", "echo()", "print()", "write()"], 2, "print() writes text to the console."],
    ["Which is a valid Python list?", ["[1, 2, 3]", "{1, 2, 3}", "(1;2;3)", "<1,2,3>"], 0, "Lists use square brackets."],
    ["Which value is a Boolean?", ["42", "\"yes\"", "True", "3.14"], 2, "True and False are Boolean values."],
    ["Which keyword creates a function?", ["func", "def", "make", "function"], 1, "Python functions start with def."],
  ],
  medium: [
    ["What does len([10, 20, 30]) return?", ["2", "3", "4", "30"], 1, "There are three items, so len is 3."],
    ["What does range(3) produce for a loop?", ["1,2,3", "0,1,2", "0,1,2,3", "3 only"], 1, "range(3) starts at 0 and stops before 3."],
    ["Which operator checks equality?", ["=", "==", "!=", ":="], 1, "== compares two values."],
    ["What does if do?", ["Repeats forever", "Checks a condition", "Defines a list", "Imports a module"], 1, "if chooses code based on a condition."],
    ["Which type stores key-value pairs?", ["list", "tuple", "dict", "string"], 2, "Dictionaries map keys to values."],
  ],
  advanced: [
    ["Which keyword handles an error branch?", ["catch", "except", "error", "rescue"], 1, "Python uses except with try for many error-handling cases."],
    ["What does a list comprehension create?", ["A faster database", "A new list from an expression/loop", "A class", "A package"], 1, "List comprehensions build lists compactly."],
    ["What does `is` primarily test?", ["String length", "Object identity", "Addition", "Loop count"], 1, "is checks whether two references point to the same object."],
    ["What is a generator useful for?", ["Streaming values lazily", "Drawing graphics only", "Changing Python syntax", "Compiling C++"], 0, "Generators yield values as needed instead of building everything at once."],
    ["Which syntax creates a dictionary safely from pairs?", ["dict(pairs)", "dictionary(pairs)", "mapdict(pairs)", "pairs.toDict()"], 0, "dict(pairs) converts key-value pairs into a dictionary."],
  ],
};

const cppBanks = {
  easy: [
    ["Which header is commonly used for std::cout?", ["<iostream>", "<print>", "<console>", "<output>"], 0, "iostream provides standard stream objects such as std::cout."],
    ["Which symbol ends a C++ statement?", [".", ";", ":", "!"], 1, "Most C++ statements end with a semicolon."],
    ["Which type stores a whole number?", ["int", "bool", "char*", "float[]"], 0, "int stores integral values."],
    ["Which keyword creates a condition?", ["when", "if", "check", "caseof"], 1, "if starts a conditional statement."],
    ["Which operator means addition?", ["+", "&", "=>", "+++"] , 0, "+ adds values."],
  ],
  medium: [
    ["Which loop repeats while a condition is true?", ["while", "match", "choose", "until"], 0, "while continues as long as its condition is true."],
    ["What does ++x do?", ["Adds one before the value is used", "Subtracts one", "Copies x", "Multiplies x by two"], 0, "Prefix increment increases x before its value is used."],
    ["Which keyword exits a loop immediately?", ["stop", "break", "exitloop", "leave"], 1, "break leaves the nearest loop or switch."],
    ["Which container grows dynamically?", ["std::vector", "std::fixedarray", "std::atom", "std::pile"], 0, "std::vector is a dynamic sequence container."],
    ["What is a reference written with?", ["&", "@", "ref", "*="], 0, "A reference declaration uses & before the variable name."],
  ],
  advanced: [
    ["What is RAII mainly about?", ["Resource lifetime tied to object lifetime", "Random access in arrays", "Runtime AI", "Recursive array indexing"], 0, "RAII binds resource management to object lifetime."],
    ["Which is a smart pointer for unique ownership?", ["std::unique_ptr", "std::share_ptr", "std::only_ptr", "std::raw_unique"], 0, "unique_ptr expresses exclusive ownership."],
    ["What does const generally communicate?", ["An intended non-modifiable value/object through that interface", "That the program is constant", "That memory is on disk", "That a loop is infinite"], 0, "const prevents modification through that const-qualified interface."],
    ["Which feature supports generic programming?", ["templates", "comments", "namespaces only", "macros only"], 0, "Templates allow code to work with many types."],
    ["Which cast is the usual choice for related compile-time conversions?", ["static_cast", "magic_cast", "any_cast_only", "convert_fast"], 0, "static_cast is intended for many explicit compile-time conversions."],
  ],
};

const blockBanks = {
  easy: [
    ["What does a stack of blocks represent?", ["A program", "A wallpaper", "A password", "A file name"], 0, "The stack is the program's instruction sequence."],
    ["Which block usually starts a project?", ["When flag tapped", "Say hello", "Move 10", "Repeat"], 0, "A hat/event block starts the program."],
    ["What does repeat do?", ["Runs blocks again", "Deletes blocks", "Changes the screen", "Logs out"], 0, "Repeat runs its nested blocks multiple times."],
    ["What is an operator useful for?", ["Calculating or comparing values", "Playing only music", "Changing your username", "Saving a photo"], 0, "Operators compute and compare values."],
    ["Where should a nested block go?", ["Inside the matching control block", "Outside the app", "On the login screen", "Only in settings"], 0, "C-shaped control blocks hold their child stack inside."],
  ],
  medium: [
    ["What does an if block do?", ["Runs its inside blocks when a condition is true", "Always repeats", "Starts Google sign-in", "Creates a username"], 0, "if evaluates a Boolean condition before running its branch."],
    ["Which block changes a score by one?", ["Change score by 1", "Set score to 1", "Say score", "Repeat score"], 0, "Change adds to the existing value."],
    ["Which is a Boolean expression?", ["7 > 3", "7 + 3", "\"hi\"", "10 steps"], 0, "A comparison evaluates to true or false."],
    ["Why nest blocks?", ["To make control flow clear and interactive", "To hide the program", "To avoid running code", "To remove operators"], 0, "Nesting makes loops and conditions control other blocks."],
    ["What should Run do?", ["Simulate the current block program", "Delete progress", "Open camera", "Change password"], 0, "Run should execute the blocks in the sandbox."],
  ],
  advanced: [
    ["What makes a block language expressive?", ["Combining data, operators, events, and control flow", "Only having more colors", "Only having more levels", "Only having animations"], 0, "Expressive block systems combine different programming concepts."],
    ["Which pattern is best for a score counter?", ["Set score to 0, then change score when points are earned", "Repeat set score to 0", "Only say score", "Delete score after every point"], 0, "Initialize once, then update when events happen."],
    ["What does a variable reporter do?", ["Reads a saved value", "Runs a loop", "Starts audio", "Moves the mascot"], 0, "A reporter block supplies a value to another block."],
    ["How can you create a reusable challenge?", ["Combine conditions, variables, operators, and nested blocks", "Use one move block only", "Disable Run", "Remove feedback"], 0, "Combining concepts creates richer interactive programs."],
    ["Why limit sandbox execution steps?", ["To prevent accidental infinite loops from freezing the app", "To make code fail randomly", "To hide correct answers", "To stop users learning"], 0, "A safe step cap keeps the interactive demo responsive."],
  ],
};

function buildLevel(course: CourseId, difficulty: Difficulty, n: number, bank: Array<any>): Level {
  const [prompt, choices, answer, explanation] = bank[n % bank.length];
  const mascot = course === "python" ? "Mr. Snakey" : course === "cpp" ? "Dr. Cilly" : "Blocky";
  const questionType: QuestionType = n % 3 === 1 ? "fill_blank" : n % 3 === 2 ? "match" : "mcq";
  let question: Question;
  if (questionType === "mcq") question = { type: "mcq", prompt, choices, answer, explanation };
  else if (questionType === "fill_blank") question = { type: "fill_blank", prompt: prompt.replace(/\?$/, " — fill the missing word/value"), answer: choices[answer], explanation };
  else question = { type: "match", prompt: "Match each idea to its role.", pairs: [
    { left: "Concept", right: prompt.replace(/\?$/, "") },
    { left: "Correct choice", right: choices[answer] },
    { left: "Why", right: explanation },
  ], explanation };

  const buildQuestion: Question = { type: "build", prompt: course === "blocks" ? "Build a small program in the sandbox." : "Try the idea in your code playground.", goal: course === "blocks" ? "Stack an event block, one action block, and one control or operator block." : "Write a tiny example that demonstrates the concept.", acceptedPatterns: course === "python" ? ["print", "def", "if", "for"] : course === "cpp" ? ["#include", "cout", "if", "for"] : ["flag", "move", "repeat", "if"], explanation: "Testing an idea makes the concept memorable." };

  const questions = [question, buildQuestion];
  return {
    id: `${course}-${difficulty}-${n + 1}`,
    course,
    difficulty,
    title: `${difficulty[0].toUpperCase() + difficulty.slice(1)} Mission ${n + 1}`,
    mascot,
    xp: difficultyXp[difficulty],
    questions,
    hint: course === "python" ? "Look for the Python keyword or value that matches the job." : course === "cpp" ? "Think about which C++ feature controls this action." : "Start with the block that describes the event, then stack the action inside." ,
  };
}

export const STEP_CODE_CURRICULUM: Level[] = (['python', 'cpp', 'blocks'] as CourseId[]).flatMap((course) => {
  const banks = course === 'python' ? pythonBanks : course === 'cpp' ? cppBanks : blockBanks;
  return (['easy', 'medium', 'advanced'] as Difficulty[]).flatMap((difficulty) =>
    Array.from({ length: 10 }, (_, i) => buildLevel(course, difficulty, i, banks[difficulty]))
  );
});

export const CURRICULUM_STATS = { courses: 3, levelsPerCourse: 30, totalLevels: 90, tiersPerCourse: 3, questionTypes: ["mcq", "fill_blank", "match", "build"] };
