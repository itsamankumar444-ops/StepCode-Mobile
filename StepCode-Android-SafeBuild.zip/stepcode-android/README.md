# StepCode Android Demo (safe build)

This version removes optional native modules (photo picker and icon package) to make the demo safer on Android. Username + emoji profile remain available; photo upload can be wired back after the base APK launches reliably.

Build: `npx eas build -p android --profile preview`
